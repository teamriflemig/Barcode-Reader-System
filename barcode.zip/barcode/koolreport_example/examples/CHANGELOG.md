# ChangeLog

## Version 1.1.1

1. Fix the Export example with wrong path

## Version 1.1.0

1. Adding the `load.koolreport.php` to easily configure path for koolreport's library
2. Adding examples for `Amazing` theme