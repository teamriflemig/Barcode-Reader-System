`MultiView` and `DrillThrough` are the same type of report. It represents same data in different types of charts so that we can have a better feel of data. For example, the sale data can be displayed in tabular format or column chart or heatmap of your choice.

In above example, the sale by month is represented in ColumnChart, LineChart and Tabular format.

The more information of MultiView widget including its documentation you may find in the [DrillDown package](https://www.koolreport.com/packages/drilldown).