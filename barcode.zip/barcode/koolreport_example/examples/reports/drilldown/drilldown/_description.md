Drill down is another most used type of report in which data is summarized in a overall level and only going to detail when needed. For example in above example, we summarize sale data by year. By clicking into column of particular year, report will load detail summary sale by month in that year. it is pretty straight-forward.


More information of DrillDown package you may find in [here](https://www.koolreport.com/packages/drilldown).