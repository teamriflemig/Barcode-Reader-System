This example demonstrates how to export table to an excel file.

```
<div>
    <?php
    \koolreport\Excel\Table::create(array(
        ...
    ));
    ?>
</div>
```