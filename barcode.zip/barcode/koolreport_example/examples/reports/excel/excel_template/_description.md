Excel package of KoolReport is able to export data from database or any other kinds of datasoure to excel file. Only that, it is able to create charts and graphs in excel files.

This example demonstrates how to use PHP template file to dynamically customize  exported excel files. The template using familiar html and widgets that allows you to create excel file easily.