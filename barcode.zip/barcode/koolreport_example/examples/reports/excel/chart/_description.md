This example demonstrates how to export chart to an excel file.

```
<div>
    <?php
    \koolreport\Excel\BarChart::create(array(
        ...
    ));
    ?>
</div>
```