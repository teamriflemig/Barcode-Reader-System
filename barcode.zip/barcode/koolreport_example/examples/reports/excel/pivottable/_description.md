This example demonstrates how to export pivot table to an excel file.

```
<div>
    <?php
    \koolreport\Excel\PivotTable::create(array(
        ...
    ));
    ?>
</div>
```