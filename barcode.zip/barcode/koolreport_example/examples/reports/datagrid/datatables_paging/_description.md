This example shows you how to set paging for DataTables.

```
DataTables::create(array(
    ...
    "options"=>array(
        "searching"=>true
    )
));
```