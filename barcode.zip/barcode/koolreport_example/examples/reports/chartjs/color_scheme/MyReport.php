<?php
require_once "../../../load.koolreport.php";
class MyReport extends \koolreport\KoolReport
{

}