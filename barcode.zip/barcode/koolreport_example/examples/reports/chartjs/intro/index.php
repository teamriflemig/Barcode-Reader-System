<?php
require_once "../../../helpers/common.php";
header("Location: $root_url/reports/chartjs/column_chart/");