<?php
require_once "../../../helpers/common.php";
header("Location: $root_url/reports/datasources/mysql_report/");