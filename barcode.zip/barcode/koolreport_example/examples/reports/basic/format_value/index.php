<?php
require_once "../../../helpers/common.php";
header("Location: $root_url/reports/koolphp_table/format_value/");