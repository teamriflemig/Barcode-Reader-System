<?php
require_once "SalesMonthsYears.php";
$SalesMonthsYears = new SalesMonthsYears;
$SalesMonthsYears->run()->render();
