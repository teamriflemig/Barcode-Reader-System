SuperCube process extends the power of Cube process. 
It allows users to create aggregated reports in one step 
that could take a lot of Cube's and other processes' steps to achieve.