One of the most used source of data is Microsoft Excel and KoolReport does support loading data from Excel file. By acquiring the  Excel package, you will be able to load data from excel file and process your data before getting them visualized.

Beside support importing data from Excel file, The `Excel` package also support exporting your data to Excel file as well. This is very convenient if you want to load your excel file, proces data then export back to another excel file as result.

More information of Excel package you may find [here](koolreport.com/packages/excel).