<?php

require_once "../../../load.koolreport.php";

use \koolreport\KoolReport;
use \koolreport\processes\Filter;
use \koolreport\processes\TimeBucket;
use \koolreport\processes\Group;
use \koolreport\processes\Limit;

class SakilaRental extends KoolReport
{
    public function settings()
    {
        //Get default connection from config.php
        $config = include "../../../config.php";

        return array(
            "dataSources"=>array(
                "sakila_rental"=>$config["sakila"]
            )
        );
    }   
    protected function setup()
    {
        $this->src('sakila_rental')
        ->query("SELECT date,markup FROM report")
        ->pipe(new TimeBucket(array(
            "date"=>"month"
        )))
        ->pipe(new Group(array(
            "by"=>"date",
            "sum"=>"markup"
        )))
        ->pipe($this->dataStore('sale_by_month'));
    } 
}
