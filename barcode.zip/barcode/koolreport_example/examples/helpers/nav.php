<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a id="baseUrl" class="navbar-brand" href="<?php echo $root_url; ?>"></a>
    <ul id="topMenu" class="navbar-nav mr-auto">
      <li class="nav-item">
   <a class="nav-link" href="http://localhost/barcode/item.php#">Back To Main</a>
 </li>

    </ul>
    <div class="my-2 my-lg-0">

    </div>
</nav>
