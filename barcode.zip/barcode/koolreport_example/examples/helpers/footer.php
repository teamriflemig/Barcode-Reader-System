<footer class="text-muted bg-dark">
    <div class="container">
    <p class="float-right">
        <button class="btn btn-secondary btn-lg"><a href="http://localhost/barcode/BarcodeHome.php">Back To Main Menu</a></button>
    <br></p>
    <p>
    </p>
    <p style="margin-top:2rem">

    </p>

    </div>
</footer>
