<?php

/**
 * If you install koolreport with composer, you only need to
 * require the composer autoload file
 * 
 * require_once dirname(__FILE__)."/vendor/autoload.php";
 */

require_once dirname(__FILE__)."/../koolreport/core/autoload.php";